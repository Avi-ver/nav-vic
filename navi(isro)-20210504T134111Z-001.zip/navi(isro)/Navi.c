// NAVI Program for the PI.
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 

// the final and initial no for the 9-10D number.
long final_random_no = 1000000000;
long initial_random_no = 900000000;

// the array to store the nos. in the array which will be need top find the loop.
long storing_data_9_10D_no[30];

// sloop
double sloop =0.0;
double SF=0.0;

// ***********************************************************************************************************************************
// this function will be generating the 9-10 Digit NO same as prs10

void delay(int number_of_seconds) 
{ 
    // Converting time into milli_seconds 
    int milli_seconds = 1000 * number_of_seconds; 
  
    // Storing start time 
    clock_t start_time = clock(); 
  
    // looping till required time is not achieved 
    while (clock() < start_time + milli_seconds) 
        ; 
} 


long PSR10_9_10_D_No() 
{ 
	int i;
	// no will be store in this varible
	long num =0;
	for (i = 0; i < 1; i++) 
		{ 
	       	 num =(rand() % (final_random_no - initial_random_no + 1)) + initial_random_no; 
	       	 //printf("%ld ", num); 
			return num;
		} 
} 
		
		
// first function 
// this function will be storing the Nos. in the array (same as sending this data into the file)
long storing_No()
{
	int i;
	long m = 0;
	for(i=0;i<30;i++)
		{
			m = PSR10_9_10_D_No(); 
			storing_data_9_10D_no[i]+=m;
			delay(1000);	
		}
		
}


//******************************
// checking the array

/*
long reading_No()
{
	int i;
	printf("the value of array \n");
	for(i=0;i<30;i++){
	printf("%ld \t",storing_data_9_10D_no[i]);
	}
}
*/

//***********************
//second function
// reading the data and finding out the sloop
int reading_the_stored_data()
{
	int i;
	for(i=0;i<1;i++)
		{
	// geting the sloop from the array
			sloop=(storing_data_9_10D_no[0]-storing_data_9_10D_no[29])/(double)30;	
			if(sloop>=0)
			SF-=sloop;
			else 
			SF+=sloop;
		}
	return 1;
}

// 3rd function 
// reading the value of sloop and then sending it to t 
// main program
int main_program(){

	int flag=0;
	int i=0;
	while(1)
		{
			storing_No();
			reading_No();
			reading_the_stored_data();
			printf("\t %.6f \n",sloop);
			printf("\t %.6f \n",SF);
			flag++;
			//delay(1100);
			 i++;
		}
	
}


int main() { 

	main_program();
	return 0; 
} 

