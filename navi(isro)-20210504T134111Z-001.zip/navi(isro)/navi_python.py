import serial
import time
import random

ser = serial.Serial('/dev/ttyACM0',9600)
data =900000000
while 1:
	time.sleep(0.9);
#	data+ = random.randint(0,2); 
	data+=1
	print("data" ,data)
	ser.write(repr(data).encode())
	#	ser.write(val);
