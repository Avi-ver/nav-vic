#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
long final_random_no = 1000000000.00;
long initial_random_no = 900000000.00;

int main()
{
double m=13.11;
m=(initial_random_no/33);
printf("%.2f",m);



}
